# LED6DRV v1 — 6-channel linear LED driver (common cathode)

2-layer FR4, 74 × 74 mm. 4× M3 corner holes (H1–H4) + 2× M3 heatsink holes (H5, H6). KiCad 7 project.

## Files
- `kicad/` — KiCad project (schematic, PCB, custom AD5628 symbol in `led6drv.kicad_sym`)
- `led6drv-gerbers.zip` — Gerbers + Excellon drill for PCBWay
- `led6drv-bom.csv`, `led6drv-cpl.csv` — BOM and pick-and-place (for PCBWay assembly)
- `led6drv-schematic.pdf` — wired circuit diagram (A3)
- `led6drv-assembly-top.pdf/.png` — A3 assembly drawing: every part with reference + value, colour-coded by function, pin-1 dots, connector pin names, channel signal chain

## PCBWay order settings
2 layers, 1.6 mm FR4, 1 oz copper (2 oz optional), HASL lead-free or ENIG,
any mask colour, min track/space 0.25/0.2 mm, min hole 0.3 mm.

## Circuit (per channel)
+5V → R4n (1 Ω sense) → Qn BCP53 emitter; collector → LED anode (J3), LED cathode → GND.
INA180A1 (gain 20) measures R4n → op-amp + input; DAC → 10 k → op-amp − input;
4.7 nF from op-amp output to − input; output → 1 k → base; 10 k base–emitter pull-up.

I_LED = V_DAC / (20 × R4n). With R4n = 1 Ω: 200 mA at 4.0 V; hard limit ≈ 245 mA
(INA180 output swing). Fit 0.5 Ω for double the current.

## Connectors
J1 (5.08 mm screw): 1 = +5 V, 2 = GND. Supply 5 V, ≥ 1.5 A.
Input protection: Q7 (AO3401A P-MOSFET) blocks reverse polarity with ≈ 60 mV drop at 1.2 A;
D1 (SMAJ5.0A TVS) clamps spikes on the 5 V rail.

J4 (1×7, optional, external DAC test input): pins 1–6 = DAC1–DAC6 (op-amp set point,
0–4 V = 0–200 mA with 1 Ω sense resistors), pin 7 = GND.
JP1–JP6 are solder jumpers, bridged by default (on-board DAC drives the channel).
To drive channel n from an external DAC: cut JPn's bridge with a knife, then drive J4 pin n.
Re-bridge with a solder blob to go back. The external DAC must share GND with this board;
keep it ≤ 5 V (the INA180 output caps the current at ≈ 245 mA anyway).
All channels at once without cutting: the AD5628 can three-state all outputs by SPI
(power-down mode, three-state); with the internal reference this applies to all 8 channels together.

J2 (2×7, to Pico, 3.3 V logic):
| pin | signal | pin | signal |
|---|---|---|---|
| 1 | 3V3 (from Pico) | 2 | GND |
| 3 | SCLK | 4 | DIN (MOSI) |
| 5 | SYNC (CS, active low) | 6 | LDAC (active low, 10 k pull-down) |
| 7 | CLR (active low, 10 k pull-up) | 8 | GND |
| 9 | OFF1 | 10 | OFF2 |
| 11 | OFF3 | 12 | OFF4 |
| 13 | OFF5 | 14 | OFF6 |

OFFn high = channel forced off (Q1n shorts the op-amp − input). 100 k pull-ups to the
Pico's 3V3 make all channels default to off. Drive OFFn low to enable.

J3 (2×6 boxed IDC, to LED board): odd pins 1,3,5,7,9,11 = LED1–LED6 anode;
even pins = GND (common cathode). Each LED line sits next to a GND conductor on ribbon cable.

## Bottom-side heatsink
The six BCP53 collector tabs connect through thermal vias (10–16 per channel) to six copper islands
on the bottom, under Q1–Q6 (outlined on the bottom silkscreen, x ≈ 49–62 mm).
Mount an aluminium bar (≈ 13 × 50 mm or larger) across them with H5/H6 (M3), on an
ELECTRICALLY INSULATING thermal pad: each island is a different LED net (LED1–LED6).
Never let bare metal touch the islands.

## Firmware notes (AD5628BRUZ-2)
- SPI mode 1 (data clocked on SCLK falling edge), 24-bit frames, up to 50 MHz.
- After power-up, send the "set up internal reference" command (enable REF, 2.5 V × 2 → 0–5 V).
  Until then outputs are zero (power-on reset = zero scale).
- 12-bit code: V = code / 4096 × 5 V → 200 mA ≈ code 3277 with R4n = 1 Ω.
- DAC outputs A–F = channels 1–6; G, H unused.

## Check before ordering
- Open in KiCad 7+ and run ERC/DRC. The routing was done with an autorouter; review it.
- Kelvin sensing: the INA180 IN+ and IN− connect to the R4n pads through the routed +5V and En
  nets. The trace drop adds ≈ 1 % gain error; per-channel calibration removes it.
- Thermal: each BCP53 dissipates up to (5 − Vf − 0.2) × I, e.g. ≈ 0.64 W for an 850 nm LED at 200 mA.
  Without the heatsink, the small top copper only suits pulsed or reduced current on the low-Vf channels;
  with the bottom heatsink fitted, 200 mA continuous is fine.
